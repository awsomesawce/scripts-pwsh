# Pwsh Aliases file
# This is where I plan to house most if not all my aliases
# Update: as of right now, this file is a placeholder.  Aliases are contained in
# `other_functions.ps1`.  The reason for this is because of how PowerShell handles Aliases.
# Separating aliases from the functions they relate to would just make things more difficult to maintain.
